# React Native Food Ordering Clone

This project contains all files from the Deliveroo Food Ordering UI clone tutorial.

Screenshots and information were taken from the [official Deliveroo app](https://deliveroo.co.uk/) and don't belong to me.

Find the [full tutorial on YouTube](https://youtu.be/FXnnCrfiNGM)!
